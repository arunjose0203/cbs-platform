// PostToolUse hook: after any change in ui/, run the portal unit tests and report failures
// back to Claude so it fixes them before moving on. Other files are ignored.
import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';

let input = {};
try { input = JSON.parse(readFileSync(0, 'utf8') || '{}'); } catch { process.exit(0); }
const file = (input?.tool_input?.file_path || '').replaceAll('\\', '/');
if (!/\/ui\/(src|test)\/[^/]+\.(m?js)$/.test(file)) process.exit(0);

const root = process.env.CLAUDE_PROJECT_DIR || input.cwd || process.cwd();
const run = spawnSync('npm test --prefix ui', { cwd: root, shell: true, encoding: 'utf8', timeout: 120000 });
if (run.status !== 0) {
  const output = `${run.stdout || ''}${run.stderr || ''}`;
  const failures = output.split('\n').filter(l => /not ok|Error|expected|actual|fail/i.test(l)).slice(0, 40).join('\n');
  process.stderr.write(`UI tests failed after editing ${file}. Fix before continuing:\n${failures || output.slice(-3000)}\n`);
  process.exit(2);
}
