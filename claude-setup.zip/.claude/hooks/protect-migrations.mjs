// PreToolUse hook: a Flyway migration that is already committed may have run on some database,
// and Flyway rejects any later change to it. Block edits to committed V<n>__*.sql files;
// new, uncommitted migrations can still be edited freely.
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';

let input = {};
try { input = JSON.parse(readFileSync(0, 'utf8') || '{}'); } catch { process.exit(0); }
const file = input?.tool_input?.file_path || '';
const normalized = file.replaceAll('\\', '/');
if (!/\/db\/(bank-)?migration\/V\d+__[^/]+\.sql$/i.test(normalized)) process.exit(0);

const root = process.env.CLAUDE_PROJECT_DIR || input.cwd || process.cwd();
const relative = path.relative(root.replaceAll('\\', '/'), normalized).replaceAll('\\', '/');
let committed;
try {
  execFileSync('git', ['ls-files', '--error-unmatch', relative], { cwd: root, stdio: 'ignore' });
  committed = true;
} catch (e) {
  // git missing: be conservative and treat any existing file as applied.
  committed = e.code === 'ENOENT' ? existsSync(file) : false;
}
if (committed) {
  process.stderr.write(`Blocked: ${relative} is a committed migration and may already be applied. ` +
    'Never change it. Create the next V<n>__description.sql instead (see the add-migration skill).\n');
  process.exit(2);
}
