---
name: add-approval-action
description: Add a new maker-checker approval action to CBS (anything that changes money, customers, limits, lists or policy). Use when a feature needs a change that must be approved by a second person.
---

# Add a maker-checker approval action

Every change that affects money, customers, limits or policy is submitted by one person and applied
only after a different person approves it. Follow all steps; a missing one fails at runtime, not compile time.

1. **Model** — add a request record in the feature's `*Models` class with `@PositiveOrZero long expectedVersion`,
   validated fields and a `@NotBlank @Size(max=500)` `reason`. Money is a `String` matching an amount pattern,
   never `double`.
2. **Enum** — add the action to `ApprovalModels.Action` (end of the list).
3. **Database constraint** — in a NEW control migration, drop and re-create `approval_request_action_check`
   with the full existing list plus the new action (copy the list from the latest migration that changed it).
   Use the `add-migration` skill.
4. **Service** — in the feature service add `validate(Tenant bank, X input)` (version + bank ACTIVE + business
   checks), `before(...)` and `values(...)` maps for the approver's preview, and
   `apply(Actor actor, UUID bankId, X input, UUID approvalId)` that locks the bank (`tenants.get(id,true)`),
   re-validates, writes, calls `tenants.change(...)` and `tenants.audit(...)`.
5. **ApprovalService** — setter-inject the service (`@Autowired void name(Service s)`), add a submit method
   `submit(actor,key,bankId,Action.X,input.expectedVersion(),input.reason(),input)`, add an
   `else if(action==Action.X)` preview branch that sets `before`, `after`, `label`, `bankId`, and a
   `case X ->` apply branch that reads the payload from `approval_request` and calls `apply`.
6. **Controller** — `@PostMapping` returning `202 ACCEPTED`, with `@RequestHeader("Idempotency-Key") UUID key`.
7. **Tests** — in `TenantAdministrationIntegrationTest`: submit, prove the maker cannot approve
   (`SELF_APPROVAL_FORBIDDEN`), approve with `approveHttp`, assert the effect and a stale-version rejection.
   UI: post with `expectedVersion` and reuse the idempotency key for an identical body.

Done when the integration test for the area and `npm.cmd test --prefix ui` pass.
