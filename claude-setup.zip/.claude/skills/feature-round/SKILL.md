---
name: feature-round
description: Plan, build, test and document a complete CBS feature (for example EMI loans or beneficiary screening) the way previous rounds were done. Use when starting a new feature, not for small fixes.
---

# Deliver a CBS feature round

1. **Understand** — read `docs/application-progress.md`, the functional-gap matrix
   (`docs/functional-gap-acceptance-matrix-*.md`) and the code of the area. State the plan and the
   defaults you will assume; ask only about decisions that cannot be undone.
2. **Branch** — `git checkout -b feature/<name>`.
3. **Build** — models, service, controller, migrations (`add-migration` skill), approvals
   (`add-approval-action` skill), portal module `ui/src/<area>-ui.js` plus nav entry, error messages in
   `ui/src/model.js`, French/Swahili labels in `ui/src/i18n.js`.
4. **Test**
   - Unit tests for pure logic.
   - One end-to-end integration test in `TenantAdministrationIntegrationTest` using real postings
     (no synthetic rows unless simulating history) — new test bank suffixes go into `TestDatabases` in
     three places.
   - UI test `ui/test/<area>.test.mjs`: escaping, versions, idempotency keys.
   - Run: UI tests, `./scripts/mvn.ps1 --batch-mode verify`, and the area's integration tests.
5. **Document** — `docs/<feature>.md` (what it does, rules, API, verification, not included),
   a dated section at the top of `docs/application-progress.md` with the test counts, and a follow-up
   line in the functional-gap matrix.
6. **Review** — use the `cbs-reviewer` agent on the diff, fix findings, then commit.
