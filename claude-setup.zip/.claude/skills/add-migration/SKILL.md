---
name: add-migration
description: Create a new Flyway database migration for CBS (control database or per-bank database) and update every version check that depends on it. Use whenever a table, column, index, constraint or trigger changes.
---

# Add a database migration

Committed migrations may already be applied and must never be edited; always add a new one.

1. **Pick the database**
   - Control (shared platform data, schema `platform`): `src/main/resources/db/migration/`
   - Each bank's own database (schema `bank`): `src/main/resources/db/bank-migration/`
2. **Number** — list the folder, take the highest `V<n>` (sort numerically, V45 > V9) and create
   `V<n+1>__short_description.sql`.
3. **Write it**
   - Money columns `NUMERIC(24,6)`; identifiers `UUID`; timestamps `TIMESTAMPTZ DEFAULT clock_timestamp()`.
   - Add `CHECK` constraints for every enum-like column and foreign keys for references.
   - Evidence tables (ledger, audit, lists, history) get an immutability trigger, never UPDATE/DELETE paths.
   - Index every column used in a hot `WHERE`; `CREATE INDEX IF NOT EXISTS`.
   - New approval actions: re-create `approval_request_action_check` with the complete list.
4. **Update the version pins** (tests fail otherwise)
   - Control migration: the expected version in `src/test/java/com/cbs/foundation/DatabaseIntegrationTest.java`.
   - Bank migration: every `schemaVersion` assertion in `TenantAdministrationIntegrationTest.java`
     and the `'drill','<n>'` value in `ops/tests/recovery_drill.py`.
5. **Grants** — new tables are covered by `ops/runtime-privileges.sql`; check it if the table needs
   unusual privileges.
6. **Verify** — run the integration tests (they apply every migration to fresh databases) and, for bank
   migrations, `python ops/tests/recovery_drill.py` when a local PostgreSQL is available.
